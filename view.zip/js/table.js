"use strict";

$(document).ready(function(){
	$('#table').DataTable({
        "order": []
    });	 
});