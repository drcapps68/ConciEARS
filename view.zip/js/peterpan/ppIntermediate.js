"use strict"


// **************PETER PAN TRIVIA  Q/A INTERMEDIATE **************************
//     Be sure to enter correctAnswer based on index # in the array
var questions = [{
    question: "how many lost boys live with Peter Pan?",
    choices: ["A) 4", "B) 5", "C) 6", "D) 7"],
    correctAnswer:2
}, {
    question: "What two colors are on Mr. Smee's shirt?",
    choices: ["A) Blue and White", "B)  Red and White", "C) Blue and Red", "D) Yellow and White"],
    correctAnswer:0
}, {
    question: "Which of the children wears a top hat and carries an umbrella?",
    choices: ["A) None of them", "B) Wendy", "C) Michael", "D) John"],
    correctAnswer:3
}, {
    question: "What is the nickname Peter Pan has for Captain Hook?",
    choices: ["A) Old Grouch", "B) Codfish", "C) Captain Smelly", "D) Catfish"],
    correctAnswer:1
}, {
    question: "What is Peter Pan looking for when he first meets Wendy?",
    choices: ["A) Never Land", "B) The Children", "C) The Lost Boys", "D) His Shadow"],
    correctAnswer:3
  }, {
      question: "What does Michael always carry with him?",
      choices: ["A) A Teddy Bear", "B) A Blanket", "C) A Book", "D) A Pillow"],
      correctAnswer:0
  }, {
      question: "Captain Hook gives Wendy and the boys a chance to join his crew by offering them the pen or the plank. Who is the first to walk the plank?",
      choices: ["A) Peter Pan", "B) John", "C) Michael", "D) Wendy"],
      correctAnswer:3
  }, {
      question: "In how many Disney Parks can you find the ride, Peter Pan's Flight?",
      choices: ["A) 1", "B) 2", "C) 3", "D) 4"],
      correctAnswer:3
  }, {
      question: "The blocks in the nursery scene of the ride actually spell out something. What is it?",
      choices: ["A) Disney", "B) Wendy", "C) Mickey", "D) Darling"],
      correctAnswer:0
  }, {
      question: "What does Mr. Darling say he needs to find before he can go to the party?",
      choices: ["A) His Pipe", "B) His Cufflinks", "C) His Shoes", "D) His Coat"],
      correctAnswer:1
}];
