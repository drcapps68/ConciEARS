"use strict"

// **************PETER PAN TRIVIA  Q/A ADVANCED **************************
//     Be sure to enter correctAnswer based on index # in the array
var questions = [{
    question: "What time is showing on Big Ben clock tower on the painted mural in the loading area of this ride?",
    choices: ["A) 7:15", "B) 2:45", "C) 5:15", "D) 10:45"],
    correctAnswer:0
}, {
    question: "What is Wendy's full name?",
    choices: ["A) Wendy Ann Darling", "B) Wendy Moira Angela Darling", "C) Wendy Llewelyn Francis Darling", "D) Wendy Rose Darling"],
    correctAnswer:1
}, {
    question: "Keeping with the tradition of the stage version, the same actor, Hans Conried, performed the voice roles of which two characters?",
    choices: ["A) Michael and John", "B) Peter Pan and Tinkerbell", "C) Captain Hook and Smee", "D) Mr. Darling and Captain Hook"],
    correctAnswer:3
}, {
    question: "The melody for the song The Second Star to the Right was originally written for which movie and was to be called Beyond the Laughing Sky?",
    choices: ["A) Dumbo", "B) Pinocchio", "C) Alice in Wonderland", "D) Mary Poppins"],
    correctAnswer:2
}, {
    question: "Originally released in 1953 this was Disney's ____ animated feature film?",
    choices: ["A) 14th", "B) 10th", "C) 18th", "D) 8th"],
    correctAnswer:0
}];
