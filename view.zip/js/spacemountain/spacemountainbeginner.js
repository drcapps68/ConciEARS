"use strict"


// **************SPACE MOUNTAIN TRIVIA  Q/A BEGINNER **************************
//     Be sure to enter correctAnswer based on index # in the array
var questions = [{
    question: "Who was the NASA astronaut that consulted on Space Mountain so the experience felt like actual space flight?",
    choices: [" Buzz Lightyear", " Gordon Cooper", " Bob Parr", " Launchpad McQuack"],
    correctAnswer: 1
}, {
    question: "True or False. Space Mountain was the world's first computer-controlled coaster",
    choices: ["True", "False"],
    correctAnswer: 0
}];
