CREATE TABLE Rides
(
    RideID VARCHAR(5) NOT NULL,
    RideName VARCHAR(50) NOT NULL
    );
	
INSERT INTO Rides
(RideID, RideName)
VALUES
("MK16", "The Magic Carpets of Aladdin"),
("MK17", "Jumgle Cruise"),
("MK19", "Pirates of the Caribbean"),
("MK26", "Splash Mountain"),
("MK28", "Big Thunder Mountain Railroad"),
("MK38", "Haunted Mansion"),
("MK44", "Prince Charming Regal Carrousel"),
("MK46", "Peter Pan's Flight"),
("MK47", "it's a small world"),
("MK55", "Dumbo the Flying Elephant"),
("MK56", "Mad Tea Party"),
("MK58", "The Many Adventures of Winnie the Pooh"),
("MK59", "Seven Dwarfs Mine Train"),
("MK72", "Stitches Great Escpae"),
("MK73", "Tomorrowland Speedway"),
("MK74", "Space Mountain"),
("MK75", "Astro Orbiter"),
("MK77", "Carousel of Progress"),
("MK78", "Buzz Lightyear's Space Ranger Spin"),
("EP1", "Spaceship Earth"),
("EP4", "Mission: SPACE"),
("EP6", "Test Track"),
("EP24", "The Sea with Nemo and Friends"),
("EP26", "Soarin"),
("EP27", "Living with the Land"),
("EP29", "Journey Into the Imagination with Figment"),
("EP58", "Grand Fiesta Tour Starring the Three Caballeros"),
("EP63", "Frozen Ever After"),
("HS1", "The Great Movie Ride"),
("HS13", "Star Tours the Adventure Continues"),
("HS29", "Toy Story Mania"),
("HS32", "Voyage of the Little Mermaid"),
("HS36", "Rock n' Roller Coaster"),
("HS37", "The Hollywood Tower of Terror"),
("AK21", "Kilimanjaro Safaris"),
("AK34", "Kali River Rapids"),
("AK35", "Expedition Everest"),
("AK50", "Primeval Whirl"),
("AK51", "TriceraTop Spin"),
("AK52", "DINOSAUR");

/*
Create ride-counter table
*/
CREATE TABLE ride_counter
(
    userID int,
    rideID varchar(5),
    FOREIGN KEY (userID) REFERENCES user_account(userID),
    FOREIGN KEY (RideID) REFERENCES Rides(RideID),
    time_stamp date
    );