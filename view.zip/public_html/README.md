# conciears
Mobile-friendly web app to engage ConciEARS clients who are waiting in line at theme parks.
