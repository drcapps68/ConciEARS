<!-- The magic kingdom rides page -->
<include href="{{ @header }}"></include>

<body>
  <div class="container-fluid">
    <div class="col-md-4 col-md-offset-4 " id="background">
      <!-- background image here (edit here) -->
      <img src="{{ @BASE }}/images/magickingdombackground2.0.png" class="img-responsive" alt="background">
    </div> 
  
    <div class="heading text-center">
      <h1>Magic Kingdom</h1>
    </div>
  
    <!-- content here -->
	 <div class="col-md-4 col-md-offset-4 centered" id="content">
      <a href="{{ @BASE }}/peterpan"class="btn btn-default btn-block">Peter Pan</a>
      
      <!-- temp back button for presentation purposes-->
      <button onclick="goBack()" class="btn btn-default btn-block">Back</button>
            <script>
              function goBack() {
                window.history.back();
              }
            </script>
      </div><!-- end of content -->
    
      <include href="{{ @footer }}"></include>

  </div> <!-- end of container fluid -->
</body>
</html>