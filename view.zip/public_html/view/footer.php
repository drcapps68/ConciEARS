                
<div class="navbar navbar-inverse navbar-fixed-bottom col-xs-12 col-sm-12 col-md-4 col-md-offset-4" id="footer">    
  <div class="row">
     <ul class="nav navbar-nav btn-group centered">
        <!--<li class="active"><a href="#">Home</a></li>-->
        <li><a href="{{ @BASE }}/homepage" class="glyphicon glyphicon-home active"></a></li>
        <!--<li><a href="/" class="glyphicon glyphicon-arrow-left"></a></li>-->
        <li><a href="http://www.conciears.com"  style="padding-top: 15px !important;">Conciears</a></li>
        <li><a href="{{ @BASE }}/homepage">Ride History</a></li>
        <li><a href="{{ @BASE }}/logout" class="glyphicon glyphicon-remove-sign"></a></li>
         
     </ul>
    </div>
</div>


