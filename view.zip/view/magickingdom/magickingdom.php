<!-- The magic kingdom rides page -->
<include href="{{ @header }}"></include>

<body>
  <div class="container-fluid">
    <div class="col-md-4 col-md-offset-4 " id="background">

      <!-- dropdown button -->
  		<!--<div class="dropdown">
  			<button class="dropbtn"><img src="/images/logo.png"/></button>
  			<div class="dropdown-content">
  				<a href="#">Sign Out</a>
  			</div>
  		</div>-->

      <!-- background image here (edit here) -->
      <img src="{{ @BASE }}/images/magickingdombackground3.0.png" class="img-responsive" alt="background">
    </div>



    <div class="heading text-center">
      <h1>Magic Kingdom Rides</h1>
    </div>



    <!-- content here -->
	 <div class="col-md-4 col-md-offset-4 centered" id="content">

   <!-- Test Area for accordian land buttons -->
   <div class="panel-group" id="accordion">

        <!-- Adventureland button -->
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#adventure" class="btn btn-default btn-block">
          Adventureland</a>
        </h4>
       <div id="adventure" class="panel-collapse collapse">
        <div class="panel-body">

          <!-- Enchanted Tiki Room button -->
          <a href="{{ @BASE }}/tikiroom"class="btn btn-default btn-block">Enchanted Tiki Room</a>
          <!-- <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Enchanted Tiki Room</a> -->

          <!-- Jungle Cruise button -->
          <a href="{{ @BASE }}/junglecruise"class="btn btn-default btn-block">Jungle Cruise</a>
          <!-- <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Jungle Cruise</a> -->

          <!-- Magic Carpets of Aladdin button -->
          <a href="{{ @BASE }}/magiccarpets"class="btn btn-default btn-block">Magic Carpets of Aladdin</a>
          <!-- <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Magic Carpets of Aladdin</a> -->

          <!-- Pirates of the Caribbean button -->
          <a href="{{ @BASE }}/pirates"class="btn btn-default btn-block">Pirates of the Caribbean</a>

          <!-- Swiss Family Tree House button -->
          <!-- <a href="{{ @BASE }}/treehouse"class="btn btn-default btn-block">Swiss Family Tree House</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Swiss Family Tree House</a>

        </div>
       </div>

        <!-- Fantasyland button -->
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#fantasy" class="btn btn-default btn-block">
          Fantasyland</a>
        </h4>
       <div id="fantasy" class="panel-collapse collapse">
        <div class="panel-body">

            <!-- The Barnstormer button -->
            <a href="{{ @BASE }}/barnstormer"class="btn btn-default btn-block">The Barnstormer</a>
            <!-- <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">The Barnstormer</a> -->

            <!-- Dumbo the Flying Elephant button -->
            <!-- <a href="{{ @BASE }}/dumbo"class="btn btn-default btn-block">Dumbo the Flying Elephant</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Dumbo the Flying Elephant</a>

            <!-- Enchanted Tales with Belle button -->
            <!-- <a href="{{ @BASE }}/enchantedtales"class="btn btn-default btn-block">Enchanted Tales with Belle</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Enchanted Tales with Belle</a>

            <!-- it's a small world button -->
            <!-- <a href="{{ @BASE }}/smallworld"class="btn btn-default btn-block">it's a small world</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">it's a small world</a>

            <!-- Mad Tea Party button -->
            <!-- <a href="{{ @BASE }}/madteaparty"class="btn btn-default btn-block">Mad Tea Party</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Mad Tea Party</a>

            <!-- The Many Adventures of Winnie the Pooh button -->
            <!-- <a href="{{ @BASE }}/winniethepooh"class="btn btn-default btn-block">The Many Adventures of Winnie the Pooh</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">The Many Adventures of Winnie the Pooh</a>

            <!-- Mickey's PhilHarmagic button -->
            <!-- <a href="{{ @BASE }}/philharmagic"class="btn btn-default btn-block">Mickey's PhilHarmagic</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Mickey's PhilHarmagic</a>

            <!-- Peter Pan's Flight button -->
            <a href="{{ @BASE }}/peterpan"class="btn btn-default btn-block">Peter Pan's Flight</a>

            <!-- Prince Charming Regal Carrousel button -->
            <!-- <a href="{{ @BASE }}/princecharming"class="btn btn-default btn-block">Prince Charming Regal Carrousel</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Prince Charming Regal Carrousel</a>

            <!-- Seven Dwarfs Mine Train button -->
            <a href="{{ @BASE }}/sevendwarfs"class="btn btn-default btn-block">Seven Dwarfs Mine Train</a>

            <!-- Under The Sea - Journey of the Little Mermaid button -->
            <!-- <a href="{{ @BASE }}/underthesea" class="btn btn-default btn-block">Under The Sea - Journey of the Little Mermaid</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Under The Sea - Journey of the Little Mermaid</a>

        </div>
      </div>


        <!-- Frontierland button -->
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#frontier" class="btn btn-default btn-block">
          Frontierland</a>
        </h4>
       <div id="frontier" class="panel-collapse collapse">
        <div class="panel-body">

            <!-- Big Thunder Mountain Railroad button -->
             <a href="{{ @BASE }}/bigthunder"class="btn btn-default btn-block">Big Thunder Mountain Railroad</a>

             <!-- Country Bear Jamboree button -->
             <!-- <a href="{{ @BASE}}/countrybearjamboree" class="btn btn-default btn-block">Country Bear Jamboree</a> -->
             <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Country Bear Jamboree</a>

             <!-- Splash Mountain button -->
             <!-- <a href="{{ @BASE }}/splashmountain"class="btn btn-default btn-block">Splash Mountain</a> -->
             <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Splash Mountain</a>

             <!-- Walt Disney World Railroad button -->
             <!-- <a href="{{ @BASE }}/wdwrailroad"class="btn btn-default btn-block">Walt Disney World Railroad</a> -->
             <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Walt Disney World Railroad</a>
        </div>
       </div>


       <!-- Liberty Square button -->
       <h4 class="panel-title">
         <a data-toggle="collapse" data-parent="#accordion" href="#liberty" class="btn btn-default btn-block">
         Liberty Square</a>
       </h4>

      <div id="liberty" class="panel-collapse collapse">
       <div class="panel-body">

            <!--Haunted Mansion button -->
            <a href="{{ @BASE }}/hauntedMansion"class="btn btn-default btn-block">Haunted Mansion</a>

            <!-- LIberty Square Riverboat button -->
            <!-- <a href="{{ @BASE}}/riverboat" class="btn btn-default btn-block">Liberty Square Riverboat</a> -->
            <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Liberty Square Riverboat</a>

       </div>
      </div>

       <!-- Main Street, USA button -->
       <h4 class="panel-title">
         <a data-toggle="collapse" data-parent="#accordion" href="#main" class="btn btn-default btn-block">
         Main Street, USA</a>
       </h4>
      <div id="main" class="panel-collapse collapse">
       <div class="panel-body">
         <!-- Walt Disney World Railroad button -->
         <!-- <a href="{{ @BASE }}/wdwrailroad"class="btn btn-default btn-block">Walt Disney World Railroad</a> -->
         <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Walt Disney World Railroad</a>
       </div>
      </div>

      <!-- Tomorrowland button -->
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#tomorrow" class="btn btn-default btn-block" style="background-color: #008CBA;">
        Tomorrowland</a>
      </h4>
     <div id="tomorrow" class="panel-collapse collapse">
      <div class="panel-body">

          <!-- Astro Orbiter button -->
          <!-- <a href="{{ @BASE }}/astroorbiter"class="btn btn-default btn-block">Astro Orbiter</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Astro Orbiter</a>

          <!-- The Buzz Lightyear's Space Ranger Spin button -->
          <!-- <a href="{{ @BASE }}/spacerangerspin"class="btn btn-default btn-block">Buzz Lightyear's Space Ranger Spin</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Buzz Lightyear's Space Ranger Spin</a>

          <!-- Carousel of Progress button -->
          <!-- <a href="{{ @BASE }}/carouselprogress"class="btn btn-default btn-block">Walt Disney's Carousel of Progress</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Walt Disney's Carousel of Progress</a>

          <!-- Monsters Inc. Laugh Floor button -->
          <!-- <a href="{{ @BASE }}/laughfloor" class="btn btn-default btn-block">Monsters Inc. Laugh Floor</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Monsters Inc. Laugh Floor</a>

          <!-- Space Mountain button -->
          <a href="{{ @BASE }}/spacemountain"class="btn btn-default btn-block">Space Mountain</a>

          <!-- Stitch's Great Escape button -->
          <!-- <a href="{{ @BASE }}/greatescape"class="btn btn-default btn-block">Stitch's Great Escape</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Stitch's Great Escape</a>

          <!-- Tomorrowland Speedway button -->
          <!-- <a href="{{ @BASE }}/speedway"class="btn btn-default btn-block">Tomorrowland Speedway</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Tomorrowland Speedway</a>

          <!-- Tomorrowland Transit Authority PeopleMover button -->
          <!-- <a href="{{ @BASE }}/peoplemover"class="btn btn-default btn-block">Tomorrowland Transit Authority PeopleMover</a> -->
          <a data-toggle="modal" data-target="#construction" class="btn btn-default btn-block">Tomorrowland Transit Authority PeopleMover</a>

      </div>
     </div>

   </div>
   <!-- End of Test Area -->



     <!-- This modal is to be removed when the ride history page has been built -->
     <!-- Modal -->
     <div id="construction" class="modal fade" role="dialog">
       <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
           <div class="modal-header">
             <button type="button" class="close" data-dismiss="modal">&times;</button>
             <h4 class="modal-title">GAWRSH!!</h4>
           </div>
           <div class="modal-body">
             <h5>This site is <strong>under construction</strong></h5>
             <p>
                <i class="fa fa-warning" style="font-size:48px;color:red"></i>
             </p>
           </div>
           <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
           </div>
          </div>
       </div>
     </div>
     <!-- End of section to be removed -->

      <!-- temp back button for presentation purposes-->
      <button onclick="goBack()" class="btn btn-default btn-block">Back</button>
            <script>
              function goBack() {
                window.history.back();
              }
            </script>
      </div><!-- end of content -->

      <include href="{{ @footer }}"></include>

  </div> <!-- end of container fluid -->
</body>
</html>
