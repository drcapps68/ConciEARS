<!-- Swiss Family Treehouse page -->
<include href="{{ @header }}"></include>

<body>
  <div class="container-fluid">
     <div class="col-md-4 col-md-offset-4" id="background">
        <!-- background image here (edit here) -->
        <img src="{{ @BASE }}/images/magickingdombackground3.0.png" class="img-responsive" alt="background">
		 </div>

		<div class=" col-md-4 col-md-offset-4 heading text-center">
			<h1>Swiss Family Treehouse</h1>
		</div>

    <!-- content here -->
		<div class="col-md-4 col-md-offset-4 centered" id="content">

			<!-- Ride information Button -->
			<a class="btn btn-default btn-block" data-toggle="modal" data-target="#ppRideModal">Ride Information</a>
			<!-- Modal -->
			<div id="ppRideModal" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Swiss Family Treehouse Information</h4>
						</div>
						<div class="modal-body">
							<h5><strong>Riders per vehicle:</strong> not applicable, walk-thru attraction</h5>
							<h5><strong>Restrictions:</strong> no height or age restriction</h5>
              <h5><strong>Fast Pass:</strong> No</h5>
							<p>
								The Swiss Family Treehouse
							</p>
							<p>
								The Swiss Family Treehouse
							</p>
							<p>
								The Swiss Family Treehouse
							</p>
							</div>
								<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								</div>
					</div>
				</div>
			</div>

			<!-- Ride counter button-->
			<a class="btn btn-default btn-block" data-toggle="modal" data-target="#ppRideCounterModal">Ride Check-In</a>
				<!--  ride counter Modal -->
				<div id="ppRideCounterModal" class="modal fade" role="dialog">
						<div class="modal-dialog">
							<!-- Modal content-->
							<div class="modal-content">
								<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Ride Check-In</h4>
								</div>
								<div class="modal-body">
										<h3>Do you want to add Swiss Family Treehouse to your ride count?</h3>
										<div>
										<!--	Yes Button-->
                    <button type="button" class="btn btn-md btn-default btn-block" id="yesRide">Yes</a>
										<div id="hiddenData" name ="rideId" hidden>{{ @rideId }}</div>

										<button type="button" class="btn btn-md btn-default btn-block" name="noRideCounter" data-dismiss="modal">No</button>

										</div>
										<br>
										<!-- Display area for Ride Count-->
										<h3 id="totalcount">You have rode this ride {{ @totalcount.totalRideCount }} times.</h3>
										<br>
										<!-- Delete the code below once the ride counter is connected to the databse-->
										<h3 id="timeStamp">The last time you rode this ride was: {{ @timestamp.timestamp }}</h3>
									</div>
									<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									</div>
							</div>
						</div>
				</div>

        <!-- Rides Nearby Button -->
        <a class="btn btn-default btn-block" data-toggle="modal" data-target="#ppNearbyRideModal">Rides Nearby</a>
        <!-- Rides Nearby Modal -->
        <div id="ppNearbyRideModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title text-center">Rides Nearby</h4>
                    </div>
                    <div class="modal-body">
                        <h3><strong>The Magic Carpets of Aladdin</strong></h3>
                        <h4>Left (east) of the ride</h4>
                        <h5><strong>Riders per vehicle:</strong> 2-4</h5>
          							<h5><strong>Restrictions:</strong> no height or age restriction</h5>
                        <br>
                        <h3><strong>Jungle Cruise</strong></h3>
                        <h4>Right (south) of the ride</h4>
                        <h5><strong>Riders per vehicle:</strong> approx. 20</h5>
          							<h5><strong>Restrictions:</strong> no height or age restriction</h5>
                        <br>
                        <h3><strong>Pirates of the Caribbean</strong></h3>
                        <h4>Right (south) of the ride</h4>
                        <h5><strong>Riders per vehicle:</strong> 23-24</h5>
          							<h5><strong>Restrictions:</strong> no height or age restriction</h5>
                        <br>
                        <h3><strong>Enchanted Tiki Room</strong></h3>
                        <h4>Left (east) of the ride</h4>
                        <h5><strong>Sit Down attraction</strong></h5>
          							<h5><strong>Restrictions:</strong> no height or age restrictions</h5>
                        <br>
                    </div>
                    <div class="modal-footer">
    								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    								</div>
                </div>
            </div>
        </div>

        <!-- Food & Dining button-->
				<a class="btn btn-default btn-block" data-toggle="modal" data-target="#ppFoodModal">Dining Nearby</a>
				<!-- food and dining Modal -->
				<div id="ppFoodModal" class="modal fade" role="dialog">
						<div class="modal-dialog">

						<!-- Modal content-->
						<div class="modal-content">
								<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Food and Dining Next to Ride</h4>
								</div>
								<div class="modal-body">
								<h3>Aloha Isle</h3>
								<h4>Left (west) of the ride</h4>
                <h5>Pricing: <strong> $</strong></h5>
								<p>This quick service counter was originally where the Sunshine Tree Tavern was before being relocated.</p>
								<p>Try the Pineapple Dole Whip Cup or grab a Souvenir Skull mug filled with Pineapple Dole Whip Float.</p>
								<br>
								<h3>Sunshine Tree Terrace</h3>
								<h4>Right (east) of the ride</h4>
                <h5>Pricing: <strong> $</strong></h5>
								<p>While visiting with Orange Bird, taste a little bit of sunshine with a classic Citrus Swirl, an orange slushy
                  mixed with soft-serve vanilla ice cream</p>
								<p>Beat the Florida heat with a raspberry-lemonade slushy or the popular Pina Colada (non-alcoholic) Slush!</p>
                <br>
                <h3>Jungle Navigation Co. Ltd. Skipper Canteen</h3>
								<h4>Right (east) of the ride</h4>
                <h5>Pricing: <strong> $$</strong></h5>
								<p>This jungle themed restaurant features dishes inspired by the cuisine of Asia, South America and Africa.
                There are 3 different rooms to dine in: the Mess Hall, the Jungle Room or the S.E.A. Room, which stands for the
              Society of Explorers and Adventurers.</p>
								<p>You may wish to try the S.E.A shu mai as an appetizer and then dive in to Trader Sam's head-on shrimp. Don't forget to save room
                for Kungaloosh!, an African-inspired chocolate cake dusted with coffee.</p>
								<br>
								<h3>Tortuga Tavern</h3>
								<h4>Left (west) of the ride</h4>
                <h5>Pricing: <strong> $</strong></h5>
								<p>If you need a quick snack while battling pirates, stop at Tortuga Tavern to fuel your sword arm.</p>
								<p>Adults can enjoy the fan-favorite turkey leg and little swashbucklers can sink their teeth into an all-beef hot dog. Don't forget
                to save room for the beautiful Tortuga Island Dessert!</p>
								</div>
								<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								</div>
						</div>
						</div>
				</div>

          <!-- Trivia button -->
          <a href="{{ @BASE }}/tikiroomtrivialevels"class="btn btn-default btn-block">Trivia</a>

			 <!-- temp back button for presentation purposes-->
			<button onclick="goBack()" class="btn btn-default btn-block">Back</button>
				<script>
						function goBack() {
								window.history.back();
						}
				</script>
		</div><!--end of content -->

			<!--- footer section -->
		<include href="{{ @footer }}"></include>

	</div> <!-- end of container fluid -->
</body>
</html>
