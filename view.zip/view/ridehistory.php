<!--this file will be changed to homepage.php --->
<include href="{{ @header }}"></include>

<body>
  <div class="container-fluid">
    <div class="col-md-4 col-md-offset-4" id="background">
      <!-- background image here (edit here) -->
			<img src="{{ @BASE }}/images/background.png" class="img-responsive" alt="background">
		</div>
		
		<!-- heading here -->
		<div class="heading text-center">
				<h1>{{ ucfirst(@first) }}s Ride History</h1>
		</div>
		
		<!-- content here -->
		<div class="col-md-4 col-md-offset-4 centered" id="content">
			
        
			<!-- table here  -->
		
			<table class="bordered" id="table">
				 <thead class="text-center">
						<tr>
							<th>Rides</th>
							<th>Dates</th>
							
						</tr>
				 </thead>
				 <tfoot>
						<tr>
							<th>Rides</th>
							<th>Dates</th>
						</tr>
					</tfoot>
					<tbody>
					<repeat group="{{ @rides }}" value="{{ @ride }}">
						<tr>
							<td>{{ @ride['ride_name'] }}</td>
							<td>{{ @ride['date'] }}</td>
	
						</tr>
					</repeat>
					</tbody>
			</table>
		
		</div><!-- end of content -->

    <!--- footer section -->
    <include href="{{ @footer }}"></include>

  </div> <!-- end of container fluid -->
	
		<script src="{{ @BASE }}/js/table.js"></script>
		

	
	
</body>
</html>
